#include <stdio.h>
#include <signal.h>

void prekidna(int sig)
{
	printf("U obradi prekida\n");
	sleep(5);
	printf("Obrada prekida gotova\n");
}

int main()
{
	struct sigaction act;
	
	act.sa_handler = prekidna;
	sigemptyset(&act.sa_mask);
	sigaddset(&act.sa_mask, SIGQUIT);
	act.sa_flags = 0;
	
	if (sigaction(SIGINT, &act, NULL)) {
		fprintf(stderr, "Nisam postavio masku za signale\n");
		perror("");
		exit(1);
	}

	while(1) ;
	
	return 0;
}